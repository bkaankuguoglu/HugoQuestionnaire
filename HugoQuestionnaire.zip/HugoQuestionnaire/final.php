<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <title> Questionnaire </title>
        <link rel="stylesheet" href = "css/style.css" type=text/css/>
      </head>

      <body>
        <header>
          <div class = "container">
            <h1>Questionnaire</h1>
          </div>
        </header>
      <main>
          <div class = "container">
              <h2>You're done!</h2>
              <p> Congrats You've completed the test</p>
              <a href="question.php?n=1" class="start">Take Again</a>
              <a href="index.php" class="start">Go to homepage</a>
          </div>
      </main>
      <footer>
      </footer>
    </body>

</html>
